using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class R_ColorTile : MonoBehaviour
{
    [SerializeField] private GameObject mTile;

    private GameObject mPlayer;

    private Vector2 mColortile;
    private void Start()
    {
        mPlayer = GameObject.FindGameObjectWithTag("Player");
    }
    
    public void Rangemark(int Range)
    {
        for(int i = 0; i < 4; i++)
        {
            for(int j = 1; j <= Range; j++)
            {
                mColortile = new Vector2(0, 0);
                if (i == 0) mColortile.x = 1; 
                if (i == 1) mColortile.x = -1; 
                if (i == 2) mColortile.y = 1; 
                if (i == 3) mColortile.y = -1;
                Instantiate(mTile, new Vector2(mPlayer.transform.position.x + mColortile.x*j, mPlayer.transform.position.y + mColortile.y*j), Quaternion.identity);
            }    
        }
    }
}
