using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private float mPlayerspeed;
    [SerializeField] private GameObject mColorTile;
    [SerializeField] private GameObject mTile;

    private float inputX, inputY;

    private Vector2 Devpos;
    private Vector2 Colpos;

    private Rigidbody2D mRigidbody2D;
    private Animator mAnimator;
    private SpriteRenderer mSpriteRenderer;

    private bool isMoving = false;
    private void Start()
    {
        mAnimator = GetComponent<Animator>();
        mRigidbody2D = GetComponent<Rigidbody2D>();
        mSpriteRenderer = GetComponent<SpriteRenderer>();
        mColorTile.GetComponent<R_ColorTile>().Rangemark(1);
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.W))
        {
            if (!isMoving)
            {
                if(Input.GetAxisRaw("Horizontal") > 0)
                {
                    inputX = 1;
                    mAnimator.SetInteger("Rota", 1);
                    mSpriteRenderer.flipX = false;
                }
                    
                else if (Input.GetAxisRaw("Horizontal") < 0)
                {
                    inputX = -1;
                    mAnimator.SetInteger("Rota", 1);
                    mSpriteRenderer.flipX = true;
                }
                    

                if (Input.GetAxisRaw("Vertical") > 0)
                {
                    inputY = 1;
                    mAnimator.SetInteger("Rota", 2);
                }
                    
                else if (Input.GetAxisRaw("Vertical") < 0)
                {
                    inputY = -1;
                    mAnimator.SetInteger("Rota", 0);
                }
                mTile.GetComponent<ColorTile>().onDestroy();
                StartCoroutine("Playermove");
            }
        }
            
                
    }
    private void FixedUpdate()
    {
    }

    IEnumerator Playermove()
    {
        
        isMoving = true;
        for(int i = 0; i < 8; i++)
        {
            transform.Translate(new Vector2(inputX, inputY) / 8);
            yield return new WaitForFixedUpdate();
        }
        inputX = 0; inputY = 0;
        Invoke("Move_delay", 0.25f);
        yield return null;
    }
    private void Move_delay()
    {
        isMoving = false;
        mColorTile.GetComponent<R_ColorTile>().Rangemark(1);
    }
}
